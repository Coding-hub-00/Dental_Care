# SmileCare Dental Clinic Web Application

A modern, responsive web application for a dental clinic with patient management, appointment booking, and admin dashboard functionality.

## 🚀 Features

### Patient Features
- **Responsive Homepage** - Clean, modern design with service highlights
- **Online Appointment Booking** - Select doctor, treatment, date, and time
- **Patient Registration/Login** - Secure authentication system
- **Patient Dashboard** - View upcoming appointments and history
- **Doctor Profiles** - Browse dentist information and specialties
- **Contact Form** - Get in touch with the clinic

### Admin Features
- **Admin Dashboard** - Comprehensive management interface
- **Appointment Management** - View, edit, confirm, and cancel appointments
- **Patient Management** - View patient details and appointment history
- **Statistics Overview** - Track appointments, patients, and revenue
- **Real-time Updates** - Instant updates across the system

### Technical Features
- **Mobile Responsive** - Optimized for all devices
- **SEO Friendly** - Proper meta tags and semantic HTML
- **Accessibility Ready** - WCAG compliant design
- **Local Storage** - Data persistence without backend
- **Modern UI/UX** - Bootstrap 5 with custom styling

## 🛠️ Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Bootstrap 5, Custom CSS with CSS Variables
- **Icons**: Font Awesome 6
- **Storage**: Local Storage (for demo purposes)
- **Responsive**: Mobile-first design approach

## 📁 Project Structure

```
smilecare-clinic/
├── index.html              # Main homepage
├── pages/
│   └── admin.html          # Admin dashboard
├── css/
│   └── style.css           # Main stylesheet
├── js/
│   ├── app.js              # Main application logic
│   └── admin.js            # Admin dashboard logic
├── images/                 # Image assets (placeholder)
├── components/             # Reusable components (future use)
└── README.md              # Project documentation
```

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No server setup required - runs entirely in the browser

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. Start exploring the application!

### Demo Credentials
- **Patient Login**: 
  - Email: `demo@patient.com`
  - Password: `demo123`
- **Admin Access**: 
  - Email: `admin@smilecare.com`
  - Password: `admin123`

## 📱 Usage Guide

### For Patients
1. **Browse Services**: Explore available dental services on the homepage
2. **Register/Login**: Create an account or login to existing account
3. **Book Appointment**: Select doctor, treatment type, and preferred time
4. **View Dashboard**: Check appointment status and history
5. **Contact Clinic**: Use the contact form for inquiries

### For Administrators
1. **Login**: Use admin credentials to access dashboard
2. **Manage Appointments**: View, confirm, or cancel patient appointments
3. **Patient Management**: View patient details and appointment history
4. **Add Appointments**: Manually create appointments for walk-in patients
5. **Monitor Statistics**: Track clinic performance and metrics

## 🎨 Design Features

### Color Scheme
- **Primary**: Blue (#2196F3) - Trust and professionalism
- **Secondary**: Light Blue (#64B5F6) - Calm and clean
- **Accent**: Dark Blue (#0D47A1) - Authority and reliability
- **Background**: Light Blue (#E3F2FD) - Soft and welcoming

### Typography
- **Font Family**: Segoe UI, system fonts for optimal readability
- **Responsive Text**: Scales appropriately across devices
- **Accessibility**: High contrast ratios for readability

### Interactive Elements
- **Hover Effects**: Smooth transitions and visual feedback
- **Loading States**: User feedback during actions
- **Form Validation**: Real-time validation with helpful messages
- **Responsive Navigation**: Mobile-friendly menu system

## 🔧 Customization

### Adding New Services
1. Update the services section in `index.html`
2. Add corresponding icons and descriptions
3. Update booking form options in JavaScript

### Modifying Doctor Profiles
1. Edit the `doctors` array in `js/app.js`
2. Add doctor images to the `images/` folder
3. Update specialties and qualifications

### Styling Changes
1. Modify CSS variables in `:root` selector in `style.css`
2. Customize component styles as needed
3. Update responsive breakpoints if required

## 📊 Data Management

### Local Storage Structure
- **appointments**: Array of appointment objects
- **patients**: Array of patient objects
- **currentUser**: Currently logged-in user data

### Sample Data Structure
```javascript
// Appointment Object
{
  id: "unique-id",
  patientId: "patient-id",
  patientName: "Patient Name",
  doctorId: "doctor-id",
  doctorName: "Doctor Name",
  treatment: "treatment-type",
  date: "YYYY-MM-DD",
  time: "HH:MM",
  status: "pending|confirmed|cancelled",
  createdAt: "ISO-date-string"
}
```

## 🚀 Deployment Options

### Static Hosting (Recommended)
- **Vercel**: Connect GitHub repo for automatic deployments
- **Netlify**: Drag and drop deployment with form handling
- **GitHub Pages**: Free hosting for public repositories
- **Firebase Hosting**: Google's fast and secure hosting

### Traditional Hosting
- Upload files to any web server
- Ensure proper MIME types for CSS and JS files
- Configure redirects if needed

## 🔮 Future Enhancements

### Backend Integration
- Replace local storage with database (MongoDB, PostgreSQL)
- Implement proper authentication with JWT tokens
- Add email notifications for appointments
- Payment processing integration

### Advanced Features
- **Calendar Integration**: Google Calendar sync
- **SMS Notifications**: Appointment reminders
- **Video Consultations**: Telemedicine capabilities
- **Medical Records**: Patient history management
- **Insurance Integration**: Claims processing
- **Multi-language Support**: Internationalization

### Technical Improvements
- **Progressive Web App**: Offline functionality
- **Real-time Updates**: WebSocket integration
- **Advanced Analytics**: Detailed reporting
- **API Integration**: Third-party services
- **Automated Testing**: Unit and integration tests

## 🐛 Troubleshooting

### Common Issues
1. **Data Not Persisting**: Check browser local storage settings
2. **Responsive Issues**: Clear browser cache and test
3. **Form Validation**: Ensure all required fields are filled
4. **Modal Not Opening**: Check Bootstrap JavaScript is loaded

### Browser Compatibility
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For support and questions:
- Create an issue in the repository
- Email: support@smilecare.com (demo)
- Documentation: Check this README file

## 🙏 Acknowledgments

- Bootstrap team for the excellent CSS framework
- Font Awesome for the comprehensive icon library
- Modern web standards for making this possible

---

**SmileCare Dental Clinic** - Your Smile, Our Priority 😊