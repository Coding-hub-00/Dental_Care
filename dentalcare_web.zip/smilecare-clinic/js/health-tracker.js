// Gamified Oral Health Tracker
class HealthTracker {
    constructor() {
        this.habits = JSON.parse(localStorage.getItem('oralHealthHabits')) || {};
        this.badges = JSON.parse(localStorage.getItem('earnedBadges')) || [];
        this.streaks = JSON.parse(localStorage.getItem('healthStreaks')) || { brushing: 0, flossing: 0 };
        this.points = parseInt(localStorage.getItem('healthPoints')) || 0;
        this.initializeTracker();
    }

    initializeTracker() {
        const today = new Date().toDateString();
        if (!this.habits[today]) {
            this.habits[today] = {
                brushing: { morning: false, evening: false },
                flossing: false,
                mouthwash: false,
                waterIntake: 0,
                sugarIntake: 'low',
                photos: []
            };
        }
    }

    logHabit(habit, value = true) {
        const today = new Date().toDateString();
        
        if (habit === 'brushing-morning') {
            this.habits[today].brushing.morning = value;
        } else if (habit === 'brushing-evening') {
            this.habits[today].brushing.evening = value;
        } else {
            this.habits[today][habit] = value;
        }
        
        this.updateStreaks();
        this.calculatePoints();
        this.checkBadges();
        this.saveData();
        this.updateUI();
    }

    updateStreaks() {
        const dates = Object.keys(this.habits).sort();
        const today = new Date().toDateString();
        
        // Calculate brushing streak
        let brushingStreak = 0;
        for (let i = dates.length - 1; i >= 0; i--) {
            const date = dates[i];
            const habits = this.habits[date];
            if (habits.brushing.morning && habits.brushing.evening) {
                brushingStreak++;
            } else {
                break;
            }
        }
        
        // Calculate flossing streak
        let flossingStreak = 0;
        for (let i = dates.length - 1; i >= 0; i--) {
            const date = dates[i];
            if (this.habits[date].flossing) {
                flossingStreak++;
            } else {
                break;
            }
        }
        
        this.streaks = { brushing: brushingStreak, flossing: flossingStreak };
    }

    calculatePoints() {
        const today = new Date().toDateString();
        const todayHabits = this.habits[today];
        
        let dailyPoints = 0;
        if (todayHabits.brushing.morning) dailyPoints += 10;
        if (todayHabits.brushing.evening) dailyPoints += 10;
        if (todayHabits.flossing) dailyPoints += 15;
        if (todayHabits.mouthwash) dailyPoints += 5;
        if (todayHabits.waterIntake >= 8) dailyPoints += 10;
        if (todayHabits.sugarIntake === 'low') dailyPoints += 5;
        
        // Streak bonuses
        if (this.streaks.brushing >= 7) dailyPoints += 20;
        if (this.streaks.flossing >= 7) dailyPoints += 25;
        
        this.points = Math.max(0, this.points + dailyPoints);
    }

    checkBadges() {
        const newBadges = [];
        
        // Streak badges
        if (this.streaks.brushing >= 7 && !this.badges.includes('week-brusher')) {
            newBadges.push({ id: 'week-brusher', name: 'Week Brusher', icon: 'fas fa-fire', color: '#FF6B35' });
        }
        if (this.streaks.brushing >= 30 && !this.badges.includes('month-brusher')) {
            newBadges.push({ id: 'month-brusher', name: 'Brushing Champion', icon: 'fas fa-crown', color: '#FFD700' });
        }
        if (this.streaks.flossing >= 7 && !this.badges.includes('floss-master')) {
            newBadges.push({ id: 'floss-master', name: 'Floss Master', icon: 'fas fa-star', color: '#4CAF50' });
        }
        
        // Point badges
        if (this.points >= 500 && !this.badges.includes('point-collector')) {
            newBadges.push({ id: 'point-collector', name: 'Point Collector', icon: 'fas fa-coins', color: '#2196F3' });
        }
        if (this.points >= 1000 && !this.badges.includes('health-warrior')) {
            newBadges.push({ id: 'health-warrior', name: 'Health Warrior', icon: 'fas fa-shield-alt', color: '#9C27B0' });
        }
        
        // Show new badge notifications
        newBadges.forEach(badge => {
            this.badges.push(badge.id);
            this.showBadgeNotification(badge);
        });
    }

    showBadgeNotification(badge) {
        const notification = document.createElement('div');
        notification.className = 'badge-notification';
        notification.innerHTML = `
            <div class="badge-content">
                <i class="${badge.icon}" style="color: ${badge.color}; font-size: 2rem;"></i>
                <h4>New Badge Earned!</h4>
                <p>${badge.name}</p>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    saveData() {
        localStorage.setItem('oralHealthHabits', JSON.stringify(this.habits));
        localStorage.setItem('earnedBadges', JSON.stringify(this.badges));
        localStorage.setItem('healthStreaks', JSON.stringify(this.streaks));
        localStorage.setItem('healthPoints', this.points.toString());
    }

    updateUI() {
        // Update tracker modal if open
        const trackerModal = document.getElementById('healthTrackerModal');
        if (trackerModal && trackerModal.classList.contains('show')) {
            this.renderTrackerContent();
        }
    }

    renderTrackerContent() {
        const today = new Date().toDateString();
        const todayHabits = this.habits[today];
        
        const content = document.getElementById('trackerContent');
        if (!content) return;
        
        content.innerHTML = `
            <div class="row mb-4">
                <div class="col-md-4 text-center">
                    <div class="points-display">
                        <div class="points-circle">
                            <span class="points-number">${this.points}</span>
                            <small>Points</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="streaks-display">
                        <div class="streak-item">
                            <i class="fas fa-fire text-danger"></i>
                            <span>Brushing: ${this.streaks.brushing} days</span>
                        </div>
                        <div class="streak-item">
                            <i class="fas fa-star text-warning"></i>
                            <span>Flossing: ${this.streaks.flossing} days</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="habits-section mb-4">
                <h5><i class="fas fa-tasks me-2"></i>Today's Habits</h5>
                <div class="habit-grid">
                    <div class="habit-item ${todayHabits.brushing.morning ? 'completed' : ''}" onclick="healthTracker.logHabit('brushing-morning', ${!todayHabits.brushing.morning})">
                        <i class="fas fa-sun"></i>
                        <span>Morning Brush</span>
                        <div class="habit-check">${todayHabits.brushing.morning ? '✓' : ''}</div>
                    </div>
                    <div class="habit-item ${todayHabits.brushing.evening ? 'completed' : ''}" onclick="healthTracker.logHabit('brushing-evening', ${!todayHabits.brushing.evening})">
                        <i class="fas fa-moon"></i>
                        <span>Evening Brush</span>
                        <div class="habit-check">${todayHabits.brushing.evening ? '✓' : ''}</div>
                    </div>
                    <div class="habit-item ${todayHabits.flossing ? 'completed' : ''}" onclick="healthTracker.logHabit('flossing', ${!todayHabits.flossing})">
                        <i class="fas fa-teeth"></i>
                        <span>Flossing</span>
                        <div class="habit-check">${todayHabits.flossing ? '✓' : ''}</div>
                    </div>
                    <div class="habit-item ${todayHabits.mouthwash ? 'completed' : ''}" onclick="healthTracker.logHabit('mouthwash', ${!todayHabits.mouthwash})">
                        <i class="fas fa-tint"></i>
                        <span>Mouthwash</span>
                        <div class="habit-check">${todayHabits.mouthwash ? '✓' : ''}</div>
                    </div>
                </div>
            </div>
            
            <div class="badges-section mb-4">
                <h5><i class="fas fa-award me-2"></i>Your Badges</h5>
                <div class="badges-grid">
                    ${this.renderBadges()}
                </div>
            </div>
            
            <div class="progress-photos">
                <h5><i class="fas fa-camera me-2"></i>Progress Photos</h5>
                <div class="photo-upload-area" onclick="document.getElementById('progressPhoto').click()">
                    <i class="fas fa-plus"></i>
                    <span>Add Progress Photo</span>
                </div>
                <input type="file" id="progressPhoto" accept="image/*" style="display: none;" onchange="healthTracker.addProgressPhoto(this)">
            </div>
        `;
    }

    renderBadges() {
        const allBadges = [
            { id: 'week-brusher', name: 'Week Brusher', icon: 'fas fa-fire', color: '#FF6B35' },
            { id: 'month-brusher', name: 'Brushing Champion', icon: 'fas fa-crown', color: '#FFD700' },
            { id: 'floss-master', name: 'Floss Master', icon: 'fas fa-star', color: '#4CAF50' },
            { id: 'point-collector', name: 'Point Collector', icon: 'fas fa-coins', color: '#2196F3' },
            { id: 'health-warrior', name: 'Health Warrior', icon: 'fas fa-shield-alt', color: '#9C27B0' }
        ];
        
        return allBadges.map(badge => {
            const earned = this.badges.includes(badge.id);
            return `
                <div class="badge-item ${earned ? 'earned' : 'locked'}">
                    <i class="${badge.icon}" style="color: ${earned ? badge.color : '#ccc'};"></i>
                    <span>${badge.name}</span>
                    ${earned ? '<div class="badge-earned">✓</div>' : '<div class="badge-locked">🔒</div>'}
                </div>
            `;
        }).join('');
    }

    addProgressPhoto(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const today = new Date().toDateString();
                this.habits[today].photos.push({
                    url: e.target.result,
                    date: new Date().toISOString()
                });
                this.saveData();
                showAlert('Progress photo added!', 'success');
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
}

// Initialize health tracker
const healthTracker = new HealthTracker();

// Show Health Tracker Modal
function showHealthTracker() {
    if (!document.getElementById('healthTrackerModal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="modal fade" id="healthTrackerModal" tabindex="-1">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient-success text-white">
                            <h5 class="modal-title">
                                <i class="fas fa-chart-line me-2"></i>Oral Health Tracker
                                <span class="badge bg-warning ms-2">GAMIFIED</span>
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div id="trackerContent">
                                <!-- Content will be rendered by JavaScript -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
    }
    
    healthTracker.renderTrackerContent();
    new bootstrap.Modal(document.getElementById('healthTrackerModal')).show();
}

// Add to global scope
window.showHealthTracker = showHealthTracker;