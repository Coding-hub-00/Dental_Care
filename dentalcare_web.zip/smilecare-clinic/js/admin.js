// Admin Dashboard JavaScript
let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
let patients = JSON.parse(localStorage.getItem('patients')) || [];

const doctors = [
    { id: 'dr-smith', name: 'Dr. John Smith', specialty: 'General Dentistry' },
    { id: 'dr-johnson', name: 'Dr. Sarah Johnson', specialty: 'Orthodontics' },
    { id: 'dr-brown', name: 'Dr. Michael Brown', specialty: 'Cosmetic Dentistry' }
];

// Initialize Dashboard
document.addEventListener('DOMContentLoaded', function() {
    loadDashboardStats();
    loadAppointments();
    loadPatients();
    loadRecentActivity();
});

// Load Dashboard Statistics
function loadDashboardStats() {
    const today = new Date().toISOString().split('T')[0];
    const todayAppointments = appointments.filter(apt => apt.date === today);
    
    document.getElementById('totalAppointments').textContent = appointments.length;
    document.getElementById('totalPatients').textContent = patients.length;
    document.getElementById('totalRevenue').textContent = `$${(appointments.length * 150).toLocaleString()}`;
    document.getElementById('todayAppointments').textContent = todayAppointments.length;
}

// Load Appointments Table
function loadAppointments() {
    const tbody = document.getElementById('appointmentsTable');
    tbody.innerHTML = appointments.map(apt => `
        <tr>
            <td>${apt.patientName}</td>
            <td>${apt.doctorName}</td>
            <td>${new Date(apt.date).toLocaleDateString()}</td>
            <td>${apt.time}</td>
            <td>
                <span class="badge bg-${getStatusColor(apt.status)}">${apt.status}</span>
            </td>
            <td>
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-success" onclick="updateStatus('${apt.id}', 'confirmed')" 
                            ${apt.status === 'confirmed' ? 'disabled' : ''}>
                        <i class="fas fa-check"></i>
                    </button>
                    <button class="btn btn-outline-warning" onclick="updateStatus('${apt.id}', 'pending')"
                            ${apt.status === 'pending' ? 'disabled' : ''}>
                        <i class="fas fa-clock"></i>
                    </button>
                    <button class="btn btn-outline-danger" onclick="updateStatus('${apt.id}', 'cancelled')"
                            ${apt.status === 'cancelled' ? 'disabled' : ''}>
                        <i class="fas fa-times"></i>
                    </button>
                    <button class="btn btn-outline-primary" onclick="editAppointment('${apt.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Load Patients Table
function loadPatients() {
    const tbody = document.getElementById('patientsTable');
    tbody.innerHTML = patients.map(patient => {
        const patientAppointments = appointments.filter(a => a.patientId === patient.id);
        return `
            <tr>
                <td>${patient.name}</td>
                <td>${patient.email}</td>
                <td>${patient.phone}</td>
                <td>${new Date(patient.registeredAt).toLocaleDateString()}</td>
                <td>${patientAppointments.length}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary" onclick="viewPatient('${patient.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-outline-secondary" onclick="editPatient('${patient.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// Load Recent Activity
function loadRecentActivity() {
    const recentActivity = document.getElementById('recentActivity');
    const recentAppointments = appointments
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5);
    
    recentActivity.innerHTML = recentAppointments.map(apt => `
        <div class="d-flex justify-content-between align-items-center mb-2 p-2 bg-light rounded">
            <div>
                <small class="fw-bold">${apt.patientName}</small><br>
                <small class="text-muted">booked with ${apt.doctorName}</small>
            </div>
            <small class="text-muted">${new Date(apt.createdAt).toLocaleDateString()}</small>
        </div>
    `).join('');
}

// Update Appointment Status
function updateStatus(appointmentId, status) {
    const index = appointments.findIndex(a => a.id === appointmentId);
    if (index !== -1) {
        appointments[index].status = status;
        localStorage.setItem('appointments', JSON.stringify(appointments));
        loadAppointments();
        loadDashboardStats();
        showAlert(`Appointment ${status} successfully!`, 'success');
    }
}

// Get Status Color
function getStatusColor(status) {
    switch(status) {
        case 'confirmed': return 'success';
        case 'cancelled': return 'danger';
        case 'completed': return 'info';
        default: return 'warning';
    }
}

// Add New Appointment
function addNewAppointment() {
    const modalHtml = `
        <div class="modal fade" id="addAppointmentModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New Appointment</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addAppointmentForm">
                            <div class="mb-3">
                                <label class="form-label">Patient Name</label>
                                <input type="text" class="form-control" name="patientName" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Patient Email</label>
                                <input type="email" class="form-control" name="patientEmail" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Doctor</label>
                                <select class="form-select" name="doctorId" required>
                                    <option value="">Select Doctor</option>
                                    ${doctors.map(doc => `<option value="${doc.id}">${doc.name}</option>`).join('')}
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Treatment</label>
                                <select class="form-select" name="treatment" required>
                                    <option value="">Select Treatment</option>
                                    <option value="checkup">Regular Checkup</option>
                                    <option value="cleaning">Teeth Cleaning</option>
                                    <option value="whitening">Teeth Whitening</option>
                                    <option value="filling">Dental Filling</option>
                                    <option value="root-canal">Root Canal</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Date</label>
                                    <input type="date" class="form-control" name="date" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Time</label>
                                    <select class="form-select" name="time" required>
                                        <option value="">Select Time</option>
                                        <option value="09:00">9:00 AM</option>
                                        <option value="10:00">10:00 AM</option>
                                        <option value="11:00">11:00 AM</option>
                                        <option value="14:00">2:00 PM</option>
                                        <option value="15:00">3:00 PM</option>
                                        <option value="16:00">4:00 PM</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea class="form-control" name="notes" rows="3"></textarea>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="saveNewAppointment()">Save Appointment</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    const modal = new bootstrap.Modal(document.getElementById('addAppointmentModal'));
    modal.show();
    
    // Remove modal from DOM when hidden
    document.getElementById('addAppointmentModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

// Save New Appointment
function saveNewAppointment() {
    const form = document.getElementById('addAppointmentForm');
    const formData = new FormData(form);
    
    const selectedDoctor = doctors.find(d => d.id === formData.get('doctorId'));
    
    const appointment = {
        id: Date.now().toString(),
        patientId: formData.get('patientEmail'),
        patientName: formData.get('patientName'),
        doctorId: formData.get('doctorId'),
        doctorName: selectedDoctor.name,
        treatment: formData.get('treatment'),
        date: formData.get('date'),
        time: formData.get('time'),
        notes: formData.get('notes'),
        status: 'confirmed',
        createdAt: new Date().toISOString()
    };
    
    appointments.push(appointment);
    localStorage.setItem('appointments', JSON.stringify(appointments));
    
    // Add patient if not exists
    const existingPatient = patients.find(p => p.email === formData.get('patientEmail'));
    if (!existingPatient) {
        const newPatient = {
            id: Date.now().toString(),
            name: formData.get('patientName'),
            email: formData.get('patientEmail'),
            phone: '',
            registeredAt: new Date().toISOString()
        };
        patients.push(newPatient);
        localStorage.setItem('patients', JSON.stringify(patients));
    }
    
    bootstrap.Modal.getInstance(document.getElementById('addAppointmentModal')).hide();
    loadDashboardStats();
    loadAppointments();
    loadPatients();
    loadRecentActivity();
    showAlert('Appointment added successfully!', 'success');
}

// Edit Appointment
function editAppointment(appointmentId) {
    const appointment = appointments.find(a => a.id === appointmentId);
    if (!appointment) return;
    
    // Similar modal to add appointment but pre-filled with existing data
    showAlert('Edit functionality would be implemented here', 'info');
}

// View Patient Details
function viewPatient(patientId) {
    const patient = patients.find(p => p.id === patientId);
    const patientAppointments = appointments.filter(a => a.patientId === patientId);
    
    const modalHtml = `
        <div class="modal fade" id="viewPatientModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Patient Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Personal Information</h6>
                                <p><strong>Name:</strong> ${patient.name}</p>
                                <p><strong>Email:</strong> ${patient.email}</p>
                                <p><strong>Phone:</strong> ${patient.phone || 'Not provided'}</p>
                                <p><strong>Registered:</strong> ${new Date(patient.registeredAt).toLocaleDateString()}</p>
                            </div>
                            <div class="col-md-6">
                                <h6>Appointment History</h6>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Doctor</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${patientAppointments.map(apt => `
                                                <tr>
                                                    <td>${new Date(apt.date).toLocaleDateString()}</td>
                                                    <td>${apt.doctorName}</td>
                                                    <td><span class="badge bg-${getStatusColor(apt.status)}">${apt.status}</span></td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    const modal = new bootstrap.Modal(document.getElementById('viewPatientModal'));
    modal.show();
    
    document.getElementById('viewPatientModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

// Edit Patient
function editPatient(patientId) {
    showAlert('Edit patient functionality would be implemented here', 'info');
}

// Utility Functions
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 100px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Initialize sample data if empty
if (appointments.length === 0) {
    const sampleAppointments = [
        {
            id: '1',
            patientId: 'patient1@example.com',
            patientName: 'John Doe',
            doctorId: 'dr-smith',
            doctorName: 'Dr. John Smith',
            treatment: 'checkup',
            date: '2024-01-15',
            time: '10:00',
            status: 'confirmed',
            createdAt: new Date().toISOString()
        },
        {
            id: '2',
            patientId: 'patient2@example.com',
            patientName: 'Jane Smith',
            doctorId: 'dr-johnson',
            doctorName: 'Dr. Sarah Johnson',
            treatment: 'cleaning',
            date: '2024-01-16',
            time: '14:00',
            status: 'pending',
            createdAt: new Date().toISOString()
        }
    ];
    
    appointments = sampleAppointments;
    localStorage.setItem('appointments', JSON.stringify(appointments));
}

if (patients.length === 0) {
    const samplePatients = [
        {
            id: 'patient1',
            name: 'John Doe',
            email: 'patient1@example.com',
            phone: '(555) 123-4567',
            registeredAt: new Date().toISOString()
        },
        {
            id: 'patient2',
            name: 'Jane Smith',
            email: 'patient2@example.com',
            phone: '(555) 987-6543',
            registeredAt: new Date().toISOString()
        }
    ];
    
    patients = samplePatients;
    localStorage.setItem('patients', JSON.stringify(patients));
}