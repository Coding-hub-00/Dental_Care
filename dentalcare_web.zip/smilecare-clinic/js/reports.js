// Reports and Analytics JavaScript
let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
let patients = JSON.parse(localStorage.getItem('patients')) || [];

const doctors = [
    { id: 'dr-smith', name: 'Dr. John Smith', specialty: 'General Dentistry' },
    { id: 'dr-johnson', name: 'Dr. Sarah Johnson', specialty: 'Orthodontics' },
    { id: 'dr-brown', name: 'Dr. Michael Brown', specialty: 'Cosmetic Dentistry' }
];

// Initialize Reports
document.addEventListener('DOMContentLoaded', function() {
    loadReportStats();
    initializeCharts();
    loadDoctorPerformance();
});

// Load Report Statistics
function loadReportStats() {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const monthlyAppointments = appointments.filter(apt => {
        const aptDate = new Date(apt.date);
        return aptDate.getMonth() === currentMonth && aptDate.getFullYear() === currentYear;
    });
    
    const newPatientsThisMonth = patients.filter(patient => {
        const regDate = new Date(patient.registeredAt);
        return regDate.getMonth() === currentMonth && regDate.getFullYear() === currentYear;
    });
    
    document.getElementById('monthlyAppointments').textContent = monthlyAppointments.length;
    document.getElementById('monthlyRevenue').textContent = `$${(monthlyAppointments.length * 150).toLocaleString()}`;
    document.getElementById('newPatients').textContent = newPatientsThisMonth.length;
    document.getElementById('satisfactionRate').textContent = '4.8';
}

// Initialize Charts
function initializeCharts() {
    createAppointmentChart();
    createTreatmentChart();
    createPeakHoursChart();
}

// Appointment Trends Chart
function createAppointmentChart() {
    const ctx = document.getElementById('appointmentChart').getContext('2d');
    
    // Generate last 6 months data
    const months = [];
    const appointmentCounts = [];
    
    for (let i = 5; i >= 0; i--) {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        months.push(date.toLocaleDateString('en-US', { month: 'short' }));
        
        // Simulate data based on existing appointments
        const count = Math.floor(Math.random() * 20) + 10;
        appointmentCounts.push(count);
    }
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: 'Appointments',
                data: appointmentCounts,
                borderColor: '#2196F3',
                backgroundColor: 'rgba(33, 150, 243, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Treatment Distribution Chart
function createTreatmentChart() {
    const ctx = document.getElementById('treatmentChart').getContext('2d');
    
    const treatments = ['Checkup', 'Cleaning', 'Whitening', 'Filling', 'Root Canal'];
    const counts = [35, 28, 15, 12, 10];
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: treatments,
            datasets: [{
                data: counts,
                backgroundColor: [
                    '#2196F3',
                    '#4CAF50',
                    '#FF9800',
                    '#9C27B0',
                    '#f44336'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Peak Hours Chart
function createPeakHoursChart() {
    const ctx = document.getElementById('peakHoursChart').getContext('2d');
    
    const hours = ['9 AM', '10 AM', '11 AM', '2 PM', '3 PM', '4 PM'];
    const bookings = [8, 12, 10, 15, 11, 7];
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: hours,
            datasets: [{
                label: 'Bookings',
                data: bookings,
                backgroundColor: '#64B5F6',
                borderColor: '#2196F3',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Load Doctor Performance
function loadDoctorPerformance() {
    const tbody = document.getElementById('doctorPerformance');
    
    const performanceData = doctors.map(doctor => {
        const doctorAppointments = appointments.filter(apt => apt.doctorId === doctor.id);
        return {
            name: doctor.name,
            appointments: doctorAppointments.length,
            rating: (4.5 + Math.random() * 0.5).toFixed(1),
            revenue: doctorAppointments.length * 150
        };
    });
    
    tbody.innerHTML = performanceData.map(data => `
        <tr>
            <td>${data.name}</td>
            <td>${data.appointments}</td>
            <td>
                <span class="rating">
                    ${generateStars(parseFloat(data.rating))} ${data.rating}
                </span>
            </td>
            <td>$${data.revenue.toLocaleString()}</td>
        </tr>
    `).join('');
}

// Generate Stars
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let stars = '';
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star text-warning"></i>';
    }
    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt text-warning"></i>';
    }
    return stars;
}

// Export Report
function exportReport(format) {
    const reportData = {
        appointments: appointments.length,
        patients: patients.length,
        revenue: appointments.length * 150,
        generatedAt: new Date().toISOString()
    };
    
    if (format === 'pdf') {
        // Simulate PDF export
        showNotification('PDF report generated successfully!', 'success');
        
        // Create downloadable content
        const content = `SmileCare Clinic Report
Generated: ${new Date().toLocaleDateString()}

Statistics:
- Total Appointments: ${reportData.appointments}
- Total Patients: ${reportData.patients}
- Total Revenue: $${reportData.revenue.toLocaleString()}

This is a demo report. In a real application, this would generate a proper PDF.`;
        
        downloadFile('smilecare-report.txt', content);
    } else if (format === 'excel') {
        // Simulate Excel export
        showNotification('Excel report generated successfully!', 'success');
        
        const csvContent = `Date,Patient,Doctor,Treatment,Status,Revenue
${appointments.map(apt => 
            `${apt.date},${apt.patientName},${apt.doctorName},${apt.treatment},${apt.status},$150`
        ).join('\n')}`;
        
        downloadFile('smilecare-appointments.csv', csvContent);
    }
}

// Generate Report
function generateReport(type) {
    let reportContent = '';
    
    switch(type) {
        case 'monthly':
            reportContent = generateMonthlyReport();
            break;
        case 'doctor':
            reportContent = generateDoctorReport();
            break;
        case 'financial':
            reportContent = generateFinancialReport();
            break;
    }
    
    showReportModal(type, reportContent);
}

function generateMonthlyReport() {
    const currentMonth = new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    return `
        <h5>Monthly Report - ${currentMonth}</h5>
        <div class="row">
            <div class="col-md-6">
                <h6>Appointments Summary</h6>
                <ul>
                    <li>Total Appointments: ${appointments.length}</li>
                    <li>Confirmed: ${appointments.filter(a => a.status === 'confirmed').length}</li>
                    <li>Pending: ${appointments.filter(a => a.status === 'pending').length}</li>
                    <li>Cancelled: ${appointments.filter(a => a.status === 'cancelled').length}</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h6>Patient Summary</h6>
                <ul>
                    <li>Total Patients: ${patients.length}</li>
                    <li>New Patients: ${Math.floor(patients.length * 0.3)}</li>
                    <li>Returning Patients: ${Math.floor(patients.length * 0.7)}</li>
                </ul>
            </div>
        </div>
    `;
}

function generateDoctorReport() {
    return `
        <h5>Doctor Performance Report</h5>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Doctor</th>
                        <th>Specialty</th>
                        <th>Appointments</th>
                        <th>Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    ${doctors.map(doctor => {
                        const doctorAppointments = appointments.filter(apt => apt.doctorId === doctor.id);
                        return `
                            <tr>
                                <td>${doctor.name}</td>
                                <td>${doctor.specialty}</td>
                                <td>${doctorAppointments.length}</td>
                                <td>$${(doctorAppointments.length * 150).toLocaleString()}</td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function generateFinancialReport() {
    const totalRevenue = appointments.length * 150;
    const monthlyRevenue = Math.floor(totalRevenue * 0.8);
    const expenses = Math.floor(totalRevenue * 0.4);
    const profit = totalRevenue - expenses;
    
    return `
        <h5>Financial Report</h5>
        <div class="row">
            <div class="col-md-6">
                <h6>Revenue Breakdown</h6>
                <ul>
                    <li>Total Revenue: $${totalRevenue.toLocaleString()}</li>
                    <li>Monthly Revenue: $${monthlyRevenue.toLocaleString()}</li>
                    <li>Average per Appointment: $150</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h6>Profit Analysis</h6>
                <ul>
                    <li>Total Expenses: $${expenses.toLocaleString()}</li>
                    <li>Net Profit: $${profit.toLocaleString()}</li>
                    <li>Profit Margin: ${((profit/totalRevenue)*100).toFixed(1)}%</li>
                </ul>
            </div>
        </div>
    `;
}

function showReportModal(type, content) {
    const modalHtml = `
        <div class="modal fade" id="reportModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${type.charAt(0).toUpperCase() + type.slice(1)} Report</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        ${content}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="exportReport('pdf')">Export PDF</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    const modal = new bootstrap.Modal(document.getElementById('reportModal'));
    modal.show();
    
    document.getElementById('reportModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });
}

function downloadFile(filename, content) {
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

function showNotification(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 100px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}