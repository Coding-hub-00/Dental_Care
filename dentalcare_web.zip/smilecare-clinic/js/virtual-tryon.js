// Virtual Try-On for Braces/Invisalign
class VirtualTryOn {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.video = null;
        this.isStreaming = false;
        this.currentFilter = 'none';
        this.faceDetector = null;
        this.initializeFaceDetection();
    }

    async initializeFaceDetection() {
        try {
            // Initialize MediaPipe Face Detection (fallback to basic detection)
            if (window.FaceDetection) {
                this.faceDetector = new FaceDetection({
                    locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${file}`
                });
            }
        } catch (error) {
            console.log('Advanced face detection not available, using fallback');
        }
    }

    async startCamera() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: 640, 
                    height: 480,
                    facingMode: 'user'
                } 
            });
            
            this.video.srcObject = stream;
            this.video.play();
            this.isStreaming = true;
            
            this.video.addEventListener('loadedmetadata', () => {
                this.canvas.width = this.video.videoWidth;
                this.canvas.height = this.video.videoHeight;
                this.startProcessing();
            });
            
        } catch (error) {
            showAlert('Camera access denied. Please allow camera permissions.', 'danger');
        }
    }

    stopCamera() {
        if (this.video && this.video.srcObject) {
            this.video.srcObject.getTracks().forEach(track => track.stop());
            this.isStreaming = false;
        }
    }

    startProcessing() {
        const processFrame = () => {
            if (!this.isStreaming) return;
            
            this.ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
            
            if (this.currentFilter !== 'none') {
                this.applyFilter();
            }
            
            requestAnimationFrame(processFrame);
        };
        
        processFrame();
    }

    applyFilter() {
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        
        switch (this.currentFilter) {
            case 'metal-braces':
                this.drawMetalBraces();
                break;
            case 'ceramic-braces':
                this.drawCeramicBraces();
                break;
            case 'invisalign':
                this.drawInvisalign();
                break;
            case 'colored-braces':
                this.drawColoredBraces();
                break;
        }
    }

    drawMetalBraces() {
        // Detect mouth area (simplified detection)
        const mouthArea = this.detectMouthArea();
        
        if (mouthArea) {
            this.ctx.strokeStyle = '#C0C0C0';
            this.ctx.lineWidth = 2;
            this.ctx.fillStyle = '#E8E8E8';
            
            // Draw brackets on teeth positions
            const bracketPositions = this.calculateBracketPositions(mouthArea);
            
            bracketPositions.forEach(pos => {
                // Draw bracket
                this.ctx.fillRect(pos.x - 3, pos.y - 2, 6, 4);
                this.ctx.strokeRect(pos.x - 3, pos.y - 2, 6, 4);
            });
            
            // Draw wire
            this.ctx.beginPath();
            this.ctx.moveTo(bracketPositions[0].x, bracketPositions[0].y);
            bracketPositions.forEach(pos => {
                this.ctx.lineTo(pos.x, pos.y);
            });
            this.ctx.stroke();
        }
    }

    drawCeramicBraces() {
        const mouthArea = this.detectMouthArea();
        
        if (mouthArea) {
            this.ctx.strokeStyle = '#F5F5DC';
            this.ctx.lineWidth = 2;
            this.ctx.fillStyle = '#FFFACD';
            
            const bracketPositions = this.calculateBracketPositions(mouthArea);
            
            bracketPositions.forEach(pos => {
                this.ctx.fillRect(pos.x - 3, pos.y - 2, 6, 4);
                this.ctx.strokeRect(pos.x - 3, pos.y - 2, 6, 4);
            });
            
            // Tooth-colored wire
            this.ctx.strokeStyle = '#F0F0F0';
            this.ctx.beginPath();
            this.ctx.moveTo(bracketPositions[0].x, bracketPositions[0].y);
            bracketPositions.forEach(pos => {
                this.ctx.lineTo(pos.x, pos.y);
            });
            this.ctx.stroke();
        }
    }

    drawInvisalign() {
        const mouthArea = this.detectMouthArea();
        
        if (mouthArea) {
            // Draw subtle clear aligner outline
            this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
            this.ctx.lineWidth = 1;
            this.ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
            
            // Draw aligner shape
            this.ctx.beginPath();
            this.ctx.ellipse(
                mouthArea.centerX, 
                mouthArea.centerY, 
                mouthArea.width * 0.4, 
                mouthArea.height * 0.3, 
                0, 0, 2 * Math.PI
            );
            this.ctx.fill();
            this.ctx.stroke();
        }
    }

    drawColoredBraces() {
        const mouthArea = this.detectMouthArea();
        
        if (mouthArea) {
            const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'];
            this.ctx.lineWidth = 2;
            
            const bracketPositions = this.calculateBracketPositions(mouthArea);
            
            bracketPositions.forEach((pos, index) => {
                const color = colors[index % colors.length];
                this.ctx.fillStyle = color;
                this.ctx.strokeStyle = color;
                
                this.ctx.fillRect(pos.x - 3, pos.y - 2, 6, 4);
                this.ctx.strokeRect(pos.x - 3, pos.y - 2, 6, 4);
            });
            
            // Silver wire
            this.ctx.strokeStyle = '#C0C0C0';
            this.ctx.beginPath();
            this.ctx.moveTo(bracketPositions[0].x, bracketPositions[0].y);
            bracketPositions.forEach(pos => {
                this.ctx.lineTo(pos.x, pos.y);
            });
            this.ctx.stroke();
        }
    }

    detectMouthArea() {
        // Simplified mouth detection (center-bottom area of face)
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height * 0.7;
        
        return {
            centerX: centerX,
            centerY: centerY,
            width: this.canvas.width * 0.3,
            height: this.canvas.height * 0.1
        };
    }

    calculateBracketPositions(mouthArea) {
        const positions = [];
        const numBrackets = 8;
        const startX = mouthArea.centerX - mouthArea.width / 2;
        const spacing = mouthArea.width / (numBrackets - 1);
        
        for (let i = 0; i < numBrackets; i++) {
            positions.push({
                x: startX + (i * spacing),
                y: mouthArea.centerY + (Math.sin(i * 0.5) * 5) // Slight curve
            });
        }
        
        return positions;
    }

    setFilter(filterType) {
        this.currentFilter = filterType;
        
        // Update UI
        document.querySelectorAll('.filter-option').forEach(option => {
            option.classList.remove('active');
        });
        
        const activeOption = document.querySelector(`[data-filter="${filterType}"]`);
        if (activeOption) {
            activeOption.classList.add('active');
        }
    }

    capturePhoto() {
        const dataURL = this.canvas.toDataURL('image/png');
        
        // Create download link
        const link = document.createElement('a');
        link.download = `virtual-tryon-${Date.now()}.png`;
        link.href = dataURL;
        link.click();
        
        showAlert('Photo captured and downloaded!', 'success');
    }
}

// Initialize virtual try-on
const virtualTryOn = new VirtualTryOn();

// Show Virtual Try-On Modal
function showVirtualTryOn() {
    if (!document.getElementById('virtualTryOnModal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="modal fade" id="virtualTryOnModal" tabindex="-1">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient-info text-white">
                            <h5 class="modal-title">
                                <i class="fas fa-magic me-2"></i>Virtual Try-On
                                <span class="badge bg-warning ms-2">AR</span>
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="camera-container">
                                        <video id="tryOnVideo" style="display: none;"></video>
                                        <canvas id="tryOnCanvas" class="w-100 border rounded"></canvas>
                                        <div class="camera-controls mt-3">
                                            <button class="btn btn-primary" onclick="startTryOn()">
                                                <i class="fas fa-video me-2"></i>Start Camera
                                            </button>
                                            <button class="btn btn-secondary" onclick="stopTryOn()">
                                                <i class="fas fa-stop me-2"></i>Stop Camera
                                            </button>
                                            <button class="btn btn-success" onclick="captureTryOn()">
                                                <i class="fas fa-camera me-2"></i>Capture Photo
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <h5><i class="fas fa-palette me-2"></i>Try Different Options</h5>
                                    <div class="filter-options">
                                        <div class="filter-option active" data-filter="none" onclick="virtualTryOn.setFilter('none')">
                                            <i class="fas fa-times"></i>
                                            <span>No Filter</span>
                                        </div>
                                        <div class="filter-option" data-filter="metal-braces" onclick="virtualTryOn.setFilter('metal-braces')">
                                            <i class="fas fa-cog"></i>
                                            <span>Metal Braces</span>
                                        </div>
                                        <div class="filter-option" data-filter="ceramic-braces" onclick="virtualTryOn.setFilter('ceramic-braces')">
                                            <i class="fas fa-gem"></i>
                                            <span>Ceramic Braces</span>
                                        </div>
                                        <div class="filter-option" data-filter="invisalign" onclick="virtualTryOn.setFilter('invisalign')">
                                            <i class="fas fa-eye-slash"></i>
                                            <span>Invisalign</span>
                                        </div>
                                        <div class="filter-option" data-filter="colored-braces" onclick="virtualTryOn.setFilter('colored-braces')">
                                            <i class="fas fa-rainbow"></i>
                                            <span>Colored Braces</span>
                                        </div>
                                    </div>
                                    
                                    <div class="treatment-info mt-4">
                                        <h6>Treatment Information</h6>
                                        <div id="treatmentDetails">
                                            <p>Select an option to see details</p>
                                        </div>
                                        <button class="btn btn-primary w-100 mt-3" onclick="bookOrthoConsultation()">
                                            <i class="fas fa-calendar-plus me-2"></i>Book Consultation
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        setupTryOnEvents();
    }
    
    new bootstrap.Modal(document.getElementById('virtualTryOnModal')).show();
}

function setupTryOnEvents() {
    virtualTryOn.canvas = document.getElementById('tryOnCanvas');
    virtualTryOn.ctx = virtualTryOn.canvas.getContext('2d');
    virtualTryOn.video = document.getElementById('tryOnVideo');
    
    // Add filter option click handlers
    document.querySelectorAll('.filter-option').forEach(option => {
        option.addEventListener('click', function() {
            const filter = this.dataset.filter;
            updateTreatmentInfo(filter);
        });
    });
}

function startTryOn() {
    virtualTryOn.startCamera();
}

function stopTryOn() {
    virtualTryOn.stopCamera();
}

function captureTryOn() {
    virtualTryOn.capturePhoto();
}

function updateTreatmentInfo(filter) {
    const details = document.getElementById('treatmentDetails');
    const info = {
        'none': '<p>Select a treatment option to see details</p>',
        'metal-braces': `
            <h6>Metal Braces</h6>
            <p><strong>Duration:</strong> 18-24 months</p>
            <p><strong>Cost:</strong> ₹40,000 - ₹80,000</p>
            <p><strong>Best for:</strong> Complex alignment issues</p>
        `,
        'ceramic-braces': `
            <h6>Ceramic Braces</h6>
            <p><strong>Duration:</strong> 18-24 months</p>
            <p><strong>Cost:</strong> ₹60,000 - ₹1,20,000</p>
            <p><strong>Best for:</strong> Discreet treatment</p>
        `,
        'invisalign': `
            <h6>Invisalign</h6>
            <p><strong>Duration:</strong> 12-18 months</p>
            <p><strong>Cost:</strong> ₹2,00,000 - ₹4,00,000</p>
            <p><strong>Best for:</strong> Mild to moderate cases</p>
        `,
        'colored-braces': `
            <h6>Colored Braces</h6>
            <p><strong>Duration:</strong> 18-24 months</p>
            <p><strong>Cost:</strong> ₹45,000 - ₹85,000</p>
            <p><strong>Best for:</strong> Young patients</p>
        `
    };
    
    details.innerHTML = info[filter] || info['none'];
}

function bookOrthoConsultation() {
    const modal = bootstrap.Modal.getInstance(document.getElementById('virtualTryOnModal'));
    modal.hide();
    setTimeout(() => showBooking(), 300);
}

// Add to global scope
window.showVirtualTryOn = showVirtualTryOn;