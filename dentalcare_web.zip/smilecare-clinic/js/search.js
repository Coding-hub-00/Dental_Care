// Advanced Search Functionality
class SearchManager {
    constructor() {
        this.appointments = JSON.parse(localStorage.getItem('appointments')) || [];
        this.patients = JSON.parse(localStorage.getItem('patients')) || [];
        this.doctors = [
            { id: 'dr-smith', name: 'Dr. John Smith', specialty: 'General Dentistry' },
            { id: 'dr-johnson', name: 'Dr. Sarah Johnson', specialty: 'Orthodontics' },
            { id: 'dr-brown', name: 'Dr. Michael Brown', specialty: 'Cosmetic Dentistry' }
        ];
        this.init();
    }

    init() {
        this.createSearchInterface();
        this.bindEvents();
    }

    createSearchInterface() {
        const searchHTML = `
            <div class="search-container">
                <div class="search-header">
                    <h5><i class="fas fa-search"></i> Advanced Search</h5>
                    <button class="btn btn-sm btn-outline-secondary" onclick="searchManager.toggleSearch()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="search-form">
                    <div class="row">
                        <div class="col-md-4">
                            <label class="form-label">Search Type</label>
                            <select class="form-select" id="searchType">
                                <option value="all">All Records</option>
                                <option value="appointments">Appointments</option>
                                <option value="patients">Patients</option>
                                <option value="doctors">Doctors</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Search Term</label>
                            <input type="text" class="form-control" id="searchTerm" placeholder="Enter search term...">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Date Range</label>
                            <input type="date" class="form-control" id="dateFrom">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-4">
                            <label class="form-label">Status Filter</label>
                            <select class="form-select" id="statusFilter">
                                <option value="">All Statuses</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="pending">Pending</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Doctor Filter</label>
                            <select class="form-select" id="doctorFilter">
                                <option value="">All Doctors</option>
                                ${this.doctors.map(doc => `<option value="${doc.id}">${doc.name}</option>`).join('')}
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button class="btn btn-primary me-2" onclick="searchManager.performSearch()">
                                <i class="fas fa-search"></i> Search
                            </button>
                            <button class="btn btn-outline-secondary" onclick="searchManager.clearSearch()">
                                <i class="fas fa-times"></i> Clear
                            </button>
                        </div>
                    </div>
                </div>
                <div class="search-results mt-4" id="searchResults" style="display: none;">
                    <h6>Search Results</h6>
                    <div id="resultsContainer"></div>
                </div>
            </div>
        `;

        // Add to page if not exists
        if (!document.getElementById('searchContainer')) {
            const container = document.createElement('div');
            container.id = 'searchContainer';
            container.className = 'search-overlay';
            container.innerHTML = searchHTML;
            container.style.display = 'none';
            document.body.appendChild(container);
        }
    }

    toggleSearch() {
        const container = document.getElementById('searchContainer');
        if (container.style.display === 'none') {
            container.style.display = 'block';
            document.getElementById('searchTerm').focus();
        } else {
            container.style.display = 'none';
            this.clearSearch();
        }
    }

    bindEvents() {
        // Real-time search
        document.addEventListener('keyup', (e) => {
            if (e.target.id === 'searchTerm') {
                if (e.target.value.length > 2) {
                    this.performSearch();
                }
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'f') {
                e.preventDefault();
                this.toggleSearch();
            }
            if (e.key === 'Escape') {
                this.toggleSearch();
            }
        });
    }

    performSearch() {
        const searchType = document.getElementById('searchType').value;
        const searchTerm = document.getElementById('searchTerm').value.toLowerCase();
        const dateFrom = document.getElementById('dateFrom').value;
        const statusFilter = document.getElementById('statusFilter').value;
        const doctorFilter = document.getElementById('doctorFilter').value;

        let results = [];

        if (searchType === 'all' || searchType === 'appointments') {
            const appointmentResults = this.searchAppointments(searchTerm, dateFrom, statusFilter, doctorFilter);
            results = results.concat(appointmentResults);
        }

        if (searchType === 'all' || searchType === 'patients') {
            const patientResults = this.searchPatients(searchTerm);
            results = results.concat(patientResults);
        }

        if (searchType === 'all' || searchType === 'doctors') {
            const doctorResults = this.searchDoctors(searchTerm);
            results = results.concat(doctorResults);
        }

        this.displayResults(results);
    }

    searchAppointments(term, dateFrom, status, doctor) {
        return this.appointments.filter(apt => {
            const matchesTerm = !term || 
                apt.patientName.toLowerCase().includes(term) ||
                apt.doctorName.toLowerCase().includes(term) ||
                apt.treatment.toLowerCase().includes(term);
            
            const matchesDate = !dateFrom || apt.date >= dateFrom;
            const matchesStatus = !status || apt.status === status;
            const matchesDoctor = !doctor || apt.doctorId === doctor;

            return matchesTerm && matchesDate && matchesStatus && matchesDoctor;
        }).map(apt => ({
            type: 'appointment',
            data: apt,
            title: `Appointment: ${apt.patientName}`,
            subtitle: `${apt.doctorName} - ${new Date(apt.date).toLocaleDateString()}`,
            status: apt.status
        }));
    }

    searchPatients(term) {
        return this.patients.filter(patient => {
            return !term || 
                patient.name.toLowerCase().includes(term) ||
                patient.email.toLowerCase().includes(term) ||
                patient.phone.includes(term);
        }).map(patient => ({
            type: 'patient',
            data: patient,
            title: `Patient: ${patient.name}`,
            subtitle: patient.email,
            status: 'active'
        }));
    }

    searchDoctors(term) {
        return this.doctors.filter(doctor => {
            return !term || 
                doctor.name.toLowerCase().includes(term) ||
                doctor.specialty.toLowerCase().includes(term);
        }).map(doctor => ({
            type: 'doctor',
            data: doctor,
            title: `Doctor: ${doctor.name}`,
            subtitle: doctor.specialty,
            status: 'available'
        }));
    }

    displayResults(results) {
        const resultsContainer = document.getElementById('resultsContainer');
        const searchResults = document.getElementById('searchResults');

        if (results.length === 0) {
            resultsContainer.innerHTML = '<p class="text-muted">No results found.</p>';
        } else {
            resultsContainer.innerHTML = results.map(result => `
                <div class="search-result-item" onclick="searchManager.selectResult('${result.type}', '${result.data.id || result.data.email}')">
                    <div class="result-icon">
                        <i class="fas fa-${this.getResultIcon(result.type)}"></i>
                    </div>
                    <div class="result-content">
                        <h6>${result.title}</h6>
                        <p class="text-muted">${result.subtitle}</p>
                    </div>
                    <div class="result-status">
                        <span class="badge bg-${this.getStatusColor(result.status)}">${result.status}</span>
                    </div>
                </div>
            `).join('');
        }

        searchResults.style.display = 'block';
    }

    getResultIcon(type) {
        const icons = {
            appointment: 'calendar-alt',
            patient: 'user',
            doctor: 'user-md'
        };
        return icons[type] || 'circle';
    }

    getStatusColor(status) {
        const colors = {
            confirmed: 'success',
            pending: 'warning',
            cancelled: 'danger',
            active: 'primary',
            available: 'success'
        };
        return colors[status] || 'secondary';
    }

    selectResult(type, id) {
        // Handle result selection based on type
        switch(type) {
            case 'appointment':
                this.showAppointmentDetails(id);
                break;
            case 'patient':
                this.showPatientDetails(id);
                break;
            case 'doctor':
                this.showDoctorDetails(id);
                break;
        }
        this.toggleSearch();
    }

    showAppointmentDetails(id) {
        const appointment = this.appointments.find(apt => apt.id === id);
        if (appointment) {
            showNotification(`Selected appointment: ${appointment.patientName} with ${appointment.doctorName}`, 'info');
        }
    }

    showPatientDetails(email) {
        const patient = this.patients.find(p => p.email === email);
        if (patient) {
            showNotification(`Selected patient: ${patient.name}`, 'info');
        }
    }

    showDoctorDetails(id) {
        const doctor = this.doctors.find(d => d.id === id);
        if (doctor) {
            showNotification(`Selected doctor: ${doctor.name}`, 'info');
        }
    }

    clearSearch() {
        document.getElementById('searchTerm').value = '';
        document.getElementById('dateFrom').value = '';
        document.getElementById('statusFilter').value = '';
        document.getElementById('doctorFilter').value = '';
        document.getElementById('searchResults').style.display = 'none';
    }
}

// Initialize search manager
document.addEventListener('DOMContentLoaded', function() {
    window.searchManager = new SearchManager();
});

// Global search function
function showSearch() {
    if (window.searchManager) {
        window.searchManager.toggleSearch();
    }
}