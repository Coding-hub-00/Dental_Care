// Eco-Friendly Rewards System
class EcoRewardsSystem {
    constructor() {
        this.userRewards = JSON.parse(localStorage.getItem('ecoRewards')) || {
            points: 0,
            level: 'Green Starter',
            totalEcoActions: 0,
            carbonSaved: 0, // in kg
            achievements: [],
            history: []
        };
        
        this.ecoActions = {
            'digital-receipt': { points: 5, carbon: 0.1, name: 'Digital Receipt' },
            'paperless-billing': { points: 20, carbon: 0.5, name: 'Paperless Billing' },
            'eco-transport': { points: 15, carbon: 2.5, name: 'Eco-Friendly Transport' },
            'bamboo-toothbrush': { points: 25, carbon: 0.3, name: 'Bamboo Toothbrush Purchase' },
            'water-conservation': { points: 10, carbon: 0.2, name: 'Water Conservation Pledge' },
            'recycle-packaging': { points: 8, carbon: 0.15, name: 'Packaging Recycling' },
            'green-referral': { points: 50, carbon: 1.0, name: 'Green Referral' }
        };
        
        this.levels = [
            { name: 'Green Starter', minPoints: 0, color: '#81C784', icon: 'fas fa-seedling' },
            { name: 'Eco Warrior', minPoints: 100, color: '#4CAF50', icon: 'fas fa-leaf' },
            { name: 'Planet Protector', minPoints: 300, color: '#2E7D32', icon: 'fas fa-globe-americas' },
            { name: 'Sustainability Champion', minPoints: 600, color: '#1B5E20', icon: 'fas fa-award' },
            { name: 'Earth Guardian', minPoints: 1000, color: '#0D4F1C', icon: 'fas fa-crown' }
        ];
        
        this.rewards = [
            { id: 'discount-10', name: '10% Treatment Discount', points: 100, type: 'discount', value: 10 },
            { id: 'free-cleaning', name: 'Free Dental Cleaning', points: 200, type: 'service', value: 'cleaning' },
            { id: 'eco-kit', name: 'Eco Dental Care Kit', points: 150, type: 'product', value: 'kit' },
            { id: 'discount-20', name: '20% Treatment Discount', points: 300, type: 'discount', value: 20 },
            { id: 'whitening-session', name: 'Free Whitening Session', points: 400, type: 'service', value: 'whitening' },
            { id: 'plant-tree', name: 'Plant a Tree (Certificate)', points: 250, type: 'environmental', value: 'tree' }
        ];
        
        this.updateLevel();
    }

    logEcoAction(actionType, customPoints = null) {
        const action = this.ecoActions[actionType];
        if (!action) return false;

        const points = customPoints || action.points;
        const carbon = action.carbon;

        this.userRewards.points += points;
        this.userRewards.totalEcoActions++;
        this.userRewards.carbonSaved += carbon;
        
        const logEntry = {
            action: actionType,
            name: action.name,
            points: points,
            carbon: carbon,
            timestamp: new Date().toISOString()
        };
        
        this.userRewards.history.unshift(logEntry);
        
        // Keep only last 50 entries
        if (this.userRewards.history.length > 50) {
            this.userRewards.history = this.userRewards.history.slice(0, 50);
        }
        
        this.updateLevel();
        this.checkAchievements();
        this.saveData();
        
        return logEntry;
    }

    updateLevel() {
        const currentPoints = this.userRewards.points;
        let newLevel = this.levels[0];
        
        for (let i = this.levels.length - 1; i >= 0; i--) {
            if (currentPoints >= this.levels[i].minPoints) {
                newLevel = this.levels[i];
                break;
            }
        }
        
        const oldLevel = this.userRewards.level;
        this.userRewards.level = newLevel.name;
        
        // Check for level up
        if (oldLevel !== newLevel.name) {
            this.showLevelUpNotification(newLevel);
        }
    }

    checkAchievements() {
        const newAchievements = [];
        
        // Points-based achievements
        if (this.userRewards.points >= 50 && !this.userRewards.achievements.includes('first-50')) {
            newAchievements.push({ id: 'first-50', name: 'First 50 Points', icon: 'fas fa-star' });
        }
        
        if (this.userRewards.points >= 200 && !this.userRewards.achievements.includes('eco-enthusiast')) {
            newAchievements.push({ id: 'eco-enthusiast', name: 'Eco Enthusiast', icon: 'fas fa-heart' });
        }
        
        // Action-based achievements
        if (this.userRewards.totalEcoActions >= 10 && !this.userRewards.achievements.includes('action-hero')) {
            newAchievements.push({ id: 'action-hero', name: 'Action Hero', icon: 'fas fa-bolt' });
        }
        
        // Carbon-based achievements
        if (this.userRewards.carbonSaved >= 5 && !this.userRewards.achievements.includes('carbon-saver')) {
            newAchievements.push({ id: 'carbon-saver', name: 'Carbon Saver', icon: 'fas fa-cloud' });
        }
        
        // Streak achievements (simplified)
        const recentActions = this.userRewards.history.slice(0, 7);
        if (recentActions.length >= 7 && !this.userRewards.achievements.includes('weekly-warrior')) {
            newAchievements.push({ id: 'weekly-warrior', name: 'Weekly Warrior', icon: 'fas fa-fire' });
        }
        
        // Add new achievements
        newAchievements.forEach(achievement => {
            this.userRewards.achievements.push(achievement.id);
            this.showAchievementNotification(achievement);
        });
    }

    redeemReward(rewardId) {
        const reward = this.rewards.find(r => r.id === rewardId);
        if (!reward || this.userRewards.points < reward.points) {
            return false;
        }
        
        this.userRewards.points -= reward.points;
        
        const redemption = {
            rewardId: rewardId,
            rewardName: reward.name,
            pointsUsed: reward.points,
            timestamp: new Date().toISOString(),
            status: 'pending'
        };
        
        if (!this.userRewards.redemptions) {
            this.userRewards.redemptions = [];
        }
        
        this.userRewards.redemptions.unshift(redemption);
        this.saveData();
        
        return redemption;
    }

    showLevelUpNotification(newLevel) {
        const notification = document.createElement('div');
        notification.className = 'level-up-notification';
        notification.innerHTML = `
            <div class="level-up-content">
                <i class="${newLevel.icon}" style="color: ${newLevel.color}; font-size: 3rem;"></i>
                <h3>Level Up!</h3>
                <p>You've reached <strong>${newLevel.name}</strong></p>
                <div class="celebration-animation">🎉</div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('show'), 100);
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 4000);
    }

    showAchievementNotification(achievement) {
        const notification = document.createElement('div');
        notification.className = 'achievement-notification';
        notification.innerHTML = `
            <div class="achievement-content">
                <i class="${achievement.icon}" style="color: #FFD700; font-size: 2rem;"></i>
                <h4>Achievement Unlocked!</h4>
                <p>${achievement.name}</p>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('show'), 100);
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    saveData() {
        localStorage.setItem('ecoRewards', JSON.stringify(this.userRewards));
    }

    getCurrentLevel() {
        return this.levels.find(level => level.name === this.userRewards.level) || this.levels[0];
    }

    getNextLevel() {
        const currentLevel = this.getCurrentLevel();
        const currentIndex = this.levels.findIndex(level => level.name === currentLevel.name);
        return currentIndex < this.levels.length - 1 ? this.levels[currentIndex + 1] : null;
    }

    getProgressToNextLevel() {
        const nextLevel = this.getNextLevel();
        if (!nextLevel) return 100;
        
        const currentLevel = this.getCurrentLevel();
        const progress = ((this.userRewards.points - currentLevel.minPoints) / 
                         (nextLevel.minPoints - currentLevel.minPoints)) * 100;
        
        return Math.min(100, Math.max(0, progress));
    }

    renderDashboard() {
        const currentLevel = this.getCurrentLevel();
        const nextLevel = this.getNextLevel();
        const progress = this.getProgressToNextLevel();
        
        return `
            <div class="eco-dashboard">
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="eco-stat-card points-card">
                            <div class="stat-icon">
                                <i class="fas fa-coins"></i>
                            </div>
                            <div class="stat-info">
                                <h3>${this.userRewards.points}</h3>
                                <p>Eco Points</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="eco-stat-card carbon-card">
                            <div class="stat-icon">
                                <i class="fas fa-leaf"></i>
                            </div>
                            <div class="stat-info">
                                <h3>${this.userRewards.carbonSaved.toFixed(1)} kg</h3>
                                <p>Carbon Saved</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="eco-stat-card actions-card">
                            <div class="stat-icon">
                                <i class="fas fa-recycle"></i>
                            </div>
                            <div class="stat-info">
                                <h3>${this.userRewards.totalEcoActions}</h3>
                                <p>Eco Actions</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="level-progress mb-4">
                    <div class="level-info">
                        <div class="current-level">
                            <i class="${currentLevel.icon}" style="color: ${currentLevel.color};"></i>
                            <span>${currentLevel.name}</span>
                        </div>
                        ${nextLevel ? `
                            <div class="next-level">
                                <span>Next: ${nextLevel.name}</span>
                                <small>${nextLevel.minPoints - this.userRewards.points} points to go</small>
                            </div>
                        ` : '<div class="max-level">Max Level Reached!</div>'}
                    </div>
                    <div class="progress-bar-container">
                        <div class="progress">
                            <div class="progress-bar bg-success" style="width: ${progress}%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="eco-actions-section">
                            <h5><i class="fas fa-plus-circle me-2"></i>Log Eco Action</h5>
                            <div class="action-buttons">
                                ${Object.entries(this.ecoActions).map(([key, action]) => `
                                    <button class="btn btn-outline-success eco-action-btn" 
                                            onclick="ecoRewards.logEcoAction('${key}'); updateEcoDashboard();">
                                        <i class="fas fa-leaf me-2"></i>${action.name}
                                        <span class="points-badge">+${action.points}</span>
                                    </button>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="rewards-section">
                            <h5><i class="fas fa-gift me-2"></i>Available Rewards</h5>
                            <div class="rewards-list">
                                ${this.rewards.map(reward => `
                                    <div class="reward-item ${this.userRewards.points >= reward.points ? 'available' : 'locked'}">
                                        <div class="reward-info">
                                            <h6>${reward.name}</h6>
                                            <span class="reward-cost">${reward.points} points</span>
                                        </div>
                                        <button class="btn btn-sm ${this.userRewards.points >= reward.points ? 'btn-primary' : 'btn-secondary'}" 
                                                ${this.userRewards.points >= reward.points ? `onclick="redeemEcoReward('${reward.id}')"` : 'disabled'}>
                                            ${this.userRewards.points >= reward.points ? 'Redeem' : 'Locked'}
                                        </button>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="achievements-section mt-4">
                    <h5><i class="fas fa-trophy me-2"></i>Achievements</h5>
                    <div class="achievements-grid">
                        ${this.renderAchievements()}
                    </div>
                </div>
                
                <div class="recent-activity mt-4">
                    <h5><i class="fas fa-history me-2"></i>Recent Activity</h5>
                    <div class="activity-list">
                        ${this.userRewards.history.slice(0, 5).map(entry => `
                            <div class="activity-item">
                                <div class="activity-info">
                                    <span class="activity-name">${entry.name}</span>
                                    <small class="activity-time">${new Date(entry.timestamp).toLocaleDateString()}</small>
                                </div>
                                <div class="activity-rewards">
                                    <span class="points-earned">+${entry.points} points</span>
                                    <span class="carbon-saved">${entry.carbon}kg CO₂</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    renderAchievements() {
        const allAchievements = [
            { id: 'first-50', name: 'First 50 Points', icon: 'fas fa-star', description: 'Earn your first 50 eco points' },
            { id: 'eco-enthusiast', name: 'Eco Enthusiast', icon: 'fas fa-heart', description: 'Reach 200 eco points' },
            { id: 'action-hero', name: 'Action Hero', icon: 'fas fa-bolt', description: 'Complete 10 eco actions' },
            { id: 'carbon-saver', name: 'Carbon Saver', icon: 'fas fa-cloud', description: 'Save 5kg of carbon' },
            { id: 'weekly-warrior', name: 'Weekly Warrior', icon: 'fas fa-fire', description: 'Complete actions for 7 days' }
        ];
        
        return allAchievements.map(achievement => {
            const earned = this.userRewards.achievements.includes(achievement.id);
            return `
                <div class="achievement-badge ${earned ? 'earned' : 'locked'}">
                    <i class="${achievement.icon}"></i>
                    <h6>${achievement.name}</h6>
                    <p>${achievement.description}</p>
                    ${earned ? '<div class="earned-check">✓</div>' : '<div class="locked-icon">🔒</div>'}
                </div>
            `;
        }).join('');
    }
}

// Initialize eco rewards system
const ecoRewards = new EcoRewardsSystem();

// Show Eco Rewards Dashboard
function showEcoRewards() {
    if (!document.getElementById('ecoRewardsModal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="modal fade" id="ecoRewardsModal" tabindex="-1">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient-success text-white">
                            <h5 class="modal-title">
                                <i class="fas fa-leaf me-2"></i>Eco-Friendly Rewards
                                <span class="badge bg-warning ms-2">SUSTAINABLE</span>
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div id="ecoDashboardContent">
                                <!-- Dashboard content will be rendered here -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
    }
    
    updateEcoDashboard();
    new bootstrap.Modal(document.getElementById('ecoRewardsModal')).show();
}

function updateEcoDashboard() {
    const container = document.getElementById('ecoDashboardContent');
    if (container) {
        container.innerHTML = ecoRewards.renderDashboard();
    }
}

function redeemEcoReward(rewardId) {
    const redemption = ecoRewards.redeemReward(rewardId);
    if (redemption) {
        showAlert(`Reward redeemed successfully! You'll receive confirmation within 24 hours.`, 'success');
        updateEcoDashboard();
    } else {
        showAlert('Insufficient points or invalid reward.', 'danger');
    }
}

// Auto-log eco actions based on user behavior
function autoLogEcoAction(actionType) {
    const logEntry = ecoRewards.logEcoAction(actionType);
    if (logEntry) {
        showAlert(`+${logEntry.points} eco points for ${logEntry.name}!`, 'success');
    }
}

// Add to global scope
window.showEcoRewards = showEcoRewards;
window.autoLogEcoAction = autoLogEcoAction;