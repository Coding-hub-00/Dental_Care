// Application State
let currentUser = null;
let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
let patients = JSON.parse(localStorage.getItem('patients')) || [];

// Sample Data
const doctors = [
    { id: 'dr-smith', name: 'Dr. John Smith', specialty: 'General Dentistry', qualification: 'DDS, 15+ years experience', rating: 4.9, avatar: 'JS' },
    { id: 'dr-johnson', name: 'Dr. Sarah Johnson', specialty: 'Orthodontics', qualification: 'DDS, MS Orthodontics, 12+ years', rating: 4.8, avatar: 'SJ' },
    { id: 'dr-brown', name: 'Dr. Michael Brown', specialty: 'Cosmetic Dentistry', qualification: 'DDS, Cosmetic Specialist, 10+ years', rating: 4.9, avatar: 'MB' }
];

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    // Hide loading screen
    setTimeout(() => {
        const loading = document.getElementById('loading');
        if (loading) {
            loading.style.opacity = '0';
            setTimeout(() => loading.style.display = 'none', 500);
        }
    }, 2000);

    // Initialize AOS
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });
    }

    // Load doctors
    loadDoctors();
    
    // Setup event listeners
    setupEventListeners();
    
    // Initialize counters
    initCounters();
    
    // Back to top button
    initBackToTop();
});

// Simple notification function
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 100px; right: 20px; z-index: 9999; min-width: 300px; animation: slideInRight 0.3s ease;';
    alertDiv.innerHTML = `
        <i class="fas fa-${getAlertIcon(type)} me-2"></i>${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
    `;
    document.body.appendChild(alertDiv);
    setTimeout(() => {
        if (alertDiv.parentElement) {
            alertDiv.style.animation = 'slideInRight 0.3s ease reverse';
            setTimeout(() => alertDiv.remove(), 300);
        }
    }, 5000);
}

function getAlertIcon(type) {
    const icons = {
        success: 'check-circle',
        danger: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Generate Star Rating
function generateStars(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalf = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }
    if (hasHalf) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }
    return stars;
}

// Load Doctors with animation
function loadDoctors() {
    const container = document.getElementById('doctorsContainer');
    if (!container) return;
    
    container.innerHTML = doctors.map((doctor, index) => `
        <div class="col-md-4" data-aos="zoom-in" data-aos-delay="${(index + 1) * 100}">
            <div class="doctor-card p-4 text-center">
                <div class="doctor-avatar">${doctor.avatar}</div>
                <h4>${doctor.name}</h4>
                <p class="text-primary fw-bold">${doctor.specialty}</p>
                <p class="small text-muted">${doctor.qualification}</p>
                <div class="rating mb-3">
                    ${generateStars(doctor.rating)} <span class="ms-2">${doctor.rating}</span>
                </div>
                <button class="btn btn-outline-primary pulse-btn" onclick="bookWithDoctor('${doctor.id}')">
                    <i class="fas fa-calendar-plus me-2"></i>Book Appointment
                </button>
            </div>
        </div>
    `).join('');
}

// Authentication Functions
function showLogin() {
    if (!document.getElementById('loginModal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="modal fade" id="loginModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title"><i class="fas fa-user me-2"></i>Patient Login</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="loginForm">
                                <div class="mb-3">
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control" placeholder="Email" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" class="form-control" placeholder="Password" required>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary w-100 pulse-btn">
                                    <i class="fas fa-sign-in-alt me-2"></i>Login
                                </button>
                                <div class="text-center mt-3">
                                    <small class="text-muted">Demo: demo@patient.com / demo123</small>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        `);
        document.getElementById('loginForm').addEventListener('submit', handleLogin);
    }
    new bootstrap.Modal(document.getElementById('loginModal')).show();
}

function showBooking() {
    if (!currentUser) {
        showAlert('Please login first to book an appointment.', 'warning');
        showLogin();
        return;
    }
    
    if (!document.getElementById('bookingModal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="modal fade" id="bookingModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title"><i class="fas fa-calendar-plus me-2"></i>Book Appointment</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="bookingForm">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fas fa-user-md me-2"></i>Select Doctor</label>
                                        <select class="form-select" name="doctorId" required>
                                            <option value="">Choose a doctor...</option>
                                            ${doctors.map(doc => `<option value="${doc.id}">${doc.name} - ${doc.specialty}</option>`).join('')}
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fas fa-procedures me-2"></i>Treatment Type</label>
                                        <select class="form-select" name="treatment" required>
                                            <option value="">Select treatment...</option>
                                            <option value="checkup">Regular Checkup</option>
                                            <option value="cleaning">Teeth Cleaning</option>
                                            <option value="whitening">Teeth Whitening</option>
                                            <option value="filling">Dental Filling</option>
                                            <option value="root-canal">Root Canal</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fas fa-calendar me-2"></i>Preferred Date</label>
                                        <input type="date" class="form-control" name="date" required min="${new Date().toISOString().split('T')[0]}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label"><i class="fas fa-clock me-2"></i>Preferred Time</label>
                                        <select class="form-select" name="time" required>
                                            <option value="">Select time...</option>
                                            <option value="09:00">9:00 AM</option>
                                            <option value="10:00">10:00 AM</option>
                                            <option value="11:00">11:00 AM</option>
                                            <option value="14:00">2:00 PM</option>
                                            <option value="15:00">3:00 PM</option>
                                            <option value="16:00">4:00 PM</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><i class="fas fa-notes-medical me-2"></i>Additional Notes</label>
                                    <textarea class="form-control" name="notes" rows="3" placeholder="Any specific concerns or requests..."></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary w-100 pulse-btn">
                                    <i class="fas fa-check me-2"></i>Book Appointment
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        `);
        document.getElementById('bookingForm').addEventListener('submit', handleBooking);
    }
    new bootstrap.Modal(document.getElementById('bookingModal')).show();
}

function handleLogin(e) {
    e.preventDefault();
    const email = e.target.querySelector('input[type="email"]').value;
    const password = e.target.querySelector('input[type="password"]').value;
    
    if (email === 'admin@smilecare.com' && password === 'admin123') {
        currentUser = { email, role: 'admin', name: 'Admin User' };
        showAlert('Admin login successful! Redirecting...', 'success');
        setTimeout(() => window.location.href = 'pages/admin.html', 1500);
    } else {
        const patient = patients.find(p => p.email === email && p.password === password);
        if (patient) {
            currentUser = { ...patient, role: 'patient' };
            showAlert(`Welcome back, ${patient.name}!`, 'success');
            updateNavigation();
        } else {
            showAlert('Invalid credentials. Try demo@patient.com / demo123 for patient login', 'danger');
        }
    }
    
    const modal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
    if (modal) modal.hide();
}

function handleBooking(e) {
    e.preventDefault();
    const selectedDoctor = doctors.find(d => d.id === e.target.doctorId.value);
    
    const appointment = {
        id: Date.now().toString(),
        patientId: currentUser.id || currentUser.email,
        patientName: currentUser.name,
        doctorId: e.target.doctorId.value,
        doctorName: selectedDoctor ? selectedDoctor.name : 'Unknown Doctor',
        treatment: e.target.treatment.value,
        date: e.target.date.value,
        time: e.target.time.value,
        notes: e.target.notes.value,
        status: 'pending',
        createdAt: new Date().toISOString()
    };
    
    appointments.push(appointment);
    localStorage.setItem('appointments', JSON.stringify(appointments));
    
    showAlert('Appointment booked successfully! We will confirm shortly.', 'success');
    
    const modal = bootstrap.Modal.getInstance(document.getElementById('bookingModal'));
    if (modal) modal.hide();
    e.target.reset();
}

function bookWithDoctor(doctorId) {
    if (!currentUser) {
        showAlert('Please login first to book an appointment.', 'warning');
        showLogin();
        return;
    }
    
    showBooking();
    setTimeout(() => {
        const select = document.querySelector('#bookingModal select[name="doctorId"]');
        if (select) select.value = doctorId;
    }, 100);
}

// Global functions for other pages
window.bookService = function(serviceType) {
    if (!currentUser) {
        showAlert('Please login first to book an appointment.', 'warning');
        showLogin();
        return;
    }
    showBooking();
};

window.showLogin = showLogin;

// Setup Event Listeners
function setupEventListeners() {
    // Contact form
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = e.target.querySelector('input[type="text"]').value;
            const email = e.target.querySelector('input[type="email"]').value;
            const message = e.target.querySelector('textarea').value;
            
            if (name && email && message) {
                showAlert('Thank you for your message! We will get back to you soon.', 'success');
                e.target.reset();
            } else {
                showAlert('Please fill in all fields.', 'warning');
            }
        });
    }

    // Newsletter form
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = e.target.querySelector('input[type="email"]').value;
            if (email) {
                showAlert('Successfully subscribed to newsletter!', 'success');
                e.target.reset();
            }
        });
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
}

// Counter Animation
function initCounters() {
    const counters = document.querySelectorAll('.counter');
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.getAttribute('data-count'));
                const increment = target / 100;
                let current = 0;

                const updateCounter = () => {
                    if (current < target) {
                        current += increment;
                        counter.textContent = Math.ceil(current);
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.textContent = target;
                    }
                };

                updateCounter();
                observer.unobserve(counter);
            }
        });
    }, observerOptions);

    counters.forEach(counter => observer.observe(counter));
}

// Back to Top Button
function initBackToTop() {
    const backToTop = document.getElementById('backToTop');
    if (!backToTop) return;

    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            backToTop.classList.add('show');
        } else {
            backToTop.classList.remove('show');
        }
    });

    backToTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// Update Navigation
function updateNavigation() {
    if (currentUser) {
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        const loginBtn = document.querySelector('.navbar .btn-primary');
        if (loginBtn) {
            loginBtn.innerHTML = `<i class="fas fa-user me-2"></i>${currentUser.name}`;
            loginBtn.onclick = () => {
                if (currentUser.role === 'admin') {
                    window.location.href = 'pages/admin.html';
                } else {
                    showAlert('Patient dashboard coming soon!', 'info');
                }
            };
        }
    }
}

// Initialize sample data
if (appointments.length === 0) {
    appointments = [
        {
            id: '1',
            patientId: 'demo@patient.com',
            patientName: 'Demo Patient',
            doctorId: 'dr-smith',
            doctorName: 'Dr. John Smith',
            treatment: 'checkup',
            date: '2024-01-15',
            time: '10:00',
            status: 'confirmed',
            createdAt: new Date().toISOString()
        }
    ];
    localStorage.setItem('appointments', JSON.stringify(appointments));
}

if (patients.length === 0) {
    patients = [
        {
            id: 'demo-patient',
            name: 'Demo Patient',
            email: 'demo@patient.com',
            phone: '+91 98765 43210',
            password: 'demo123',
            registeredAt: new Date().toISOString()
        },
        {
            id: 'patient-2',
            name: 'Rahul Sharma',
            email: 'rahul@example.com',
            phone: '+91 98765 43211',
            password: 'patient123',
            registeredAt: new Date().toISOString()
        },
        {
            id: 'patient-3',
            name: 'Priya Patel',
            email: 'priya@example.com',
            phone: '+91 98765 43212',
            password: 'patient123',
            registeredAt: new Date().toISOString()
        }
    ];
    localStorage.setItem('patients', JSON.stringify(patients));
}