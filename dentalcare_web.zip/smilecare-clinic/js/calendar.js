// Simple calendar placeholder
window.selectTimeSlot = function(time) {
    const timeSelect = document.querySelector('#bookingModal select[name="time"]');
    if (timeSelect) {
        timeSelect.value = time;
    }
};