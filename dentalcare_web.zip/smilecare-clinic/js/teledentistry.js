// Teledentistry Marketplace
class TeledentistryMarketplace {
    constructor() {
        this.specialists = [
            {
                id: 'endo-1',
                name: 'Dr. Rajesh Kumar',
                specialty: 'Endodontist',
                experience: '15+ years',
                rating: 4.9,
                consultationFee: 1500,
                languages: ['Hindi', 'English', 'Marathi'],
                availability: 'Mon-Fri 9AM-6PM',
                avatar: 'RK',
                verified: true,
                specializations: ['Root Canal', 'Pulp Therapy', 'Dental Trauma']
            },
            {
                id: 'ortho-1',
                name: 'Dr. Priya Sharma',
                specialty: 'Orthodontist',
                experience: '12+ years',
                rating: 4.8,
                consultationFee: 2000,
                languages: ['Hindi', 'English', 'Gujarati'],
                availability: 'Tue-Sat 10AM-7PM',
                avatar: 'PS',
                verified: true,
                specializations: ['Braces', 'Invisalign', 'Jaw Alignment']
            },
            {
                id: 'oral-1',
                name: 'Dr. Amit Patel',
                specialty: 'Oral Surgeon',
                experience: '18+ years',
                rating: 4.9,
                consultationFee: 2500,
                languages: ['Hindi', 'English', 'Gujarati'],
                availability: 'Mon-Thu 8AM-5PM',
                avatar: 'AP',
                verified: true,
                specializations: ['Wisdom Teeth', 'Implants', 'Jaw Surgery']
            },
            {
                id: 'perio-1',
                name: 'Dr. Sunita Reddy',
                specialty: 'Periodontist',
                experience: '10+ years',
                rating: 4.7,
                consultationFee: 1800,
                languages: ['Hindi', 'English', 'Telugu'],
                availability: 'Wed-Sun 9AM-6PM',
                avatar: 'SR',
                verified: true,
                specializations: ['Gum Disease', 'Dental Implants', 'Gum Surgery']
            }
        ];
        
        this.consultations = JSON.parse(localStorage.getItem('teledentistryConsultations')) || [];
    }

    searchSpecialists(specialty = '', minRating = 0, maxFee = 10000) {
        return this.specialists.filter(specialist => {
            const matchesSpecialty = !specialty || specialist.specialty.toLowerCase().includes(specialty.toLowerCase());
            const matchesRating = specialist.rating >= minRating;
            const matchesFee = specialist.consultationFee <= maxFee;
            
            return matchesSpecialty && matchesRating && matchesFee;
        });
    }

    bookConsultation(specialistId, consultationType, preferredDate, preferredTime, symptoms, files = []) {
        const specialist = this.specialists.find(s => s.id === specialistId);
        if (!specialist) return null;

        const consultation = {
            id: Date.now().toString(),
            specialistId: specialistId,
            specialistName: specialist.name,
            patientId: currentUser?.id || 'guest',
            patientName: currentUser?.name || 'Guest User',
            consultationType: consultationType,
            preferredDate: preferredDate,
            preferredTime: preferredTime,
            symptoms: symptoms,
            files: files,
            status: 'pending',
            fee: specialist.consultationFee,
            createdAt: new Date().toISOString(),
            meetingLink: null
        };

        this.consultations.push(consultation);
        localStorage.setItem('teledentistryConsultations', JSON.stringify(this.consultations));
        
        return consultation;
    }

    generateMeetingLink(consultationId) {
        // Simulate meeting link generation (would integrate with Zoom/Teams API)
        const meetingId = Math.random().toString(36).substring(2, 15);
        return `https://smilecare.zoom.us/j/${meetingId}`;
    }

    renderSpecialistCard(specialist) {
        return `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="specialist-card h-100">
                    <div class="specialist-header">
                        <div class="specialist-avatar">${specialist.avatar}</div>
                        <div class="specialist-info">
                            <h5>${specialist.name}</h5>
                            <p class="text-primary">${specialist.specialty}</p>
                            ${specialist.verified ? '<span class="verified-badge"><i class="fas fa-check-circle"></i> Verified</span>' : ''}
                        </div>
                    </div>
                    
                    <div class="specialist-details">
                        <div class="detail-item">
                            <i class="fas fa-star text-warning"></i>
                            <span>${specialist.rating} (${Math.floor(Math.random() * 200 + 50)} reviews)</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-clock text-info"></i>
                            <span>${specialist.experience}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-rupee-sign text-success"></i>
                            <span>₹${specialist.consultationFee} per consultation</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-language text-secondary"></i>
                            <span>${specialist.languages.join(', ')}</span>
                        </div>
                    </div>
                    
                    <div class="specializations">
                        <h6>Specializations:</h6>
                        <div class="specialization-tags">
                            ${specialist.specializations.map(spec => `<span class="spec-tag">${spec}</span>`).join('')}
                        </div>
                    </div>
                    
                    <div class="availability">
                        <i class="fas fa-calendar-alt text-primary"></i>
                        <span>${specialist.availability}</span>
                    </div>
                    
                    <div class="specialist-actions">
                        <button class="btn btn-primary w-100" onclick="bookTeledentistryConsultation('${specialist.id}')">
                            <i class="fas fa-video me-2"></i>Book Video Consultation
                        </button>
                        <button class="btn btn-outline-secondary w-100 mt-2" onclick="viewSpecialistProfile('${specialist.id}')">
                            <i class="fas fa-user me-2"></i>View Profile
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    renderConsultationHistory() {
        if (this.consultations.length === 0) {
            return '<div class="text-center py-4"><p>No consultations yet</p></div>';
        }

        return this.consultations.map(consultation => {
            const specialist = this.specialists.find(s => s.id === consultation.specialistId);
            const statusColor = {
                'pending': 'warning',
                'confirmed': 'success',
                'completed': 'info',
                'cancelled': 'danger'
            };

            return `
                <div class="consultation-item mb-3">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6>${consultation.specialistName}</h6>
                            <p class="mb-1">${consultation.consultationType} - ${consultation.preferredDate} at ${consultation.preferredTime}</p>
                            <small class="text-muted">Symptoms: ${consultation.symptoms}</small>
                        </div>
                        <div class="col-md-4 text-end">
                            <span class="badge bg-${statusColor[consultation.status]} mb-2">${consultation.status.toUpperCase()}</span>
                            <div>₹${consultation.fee}</div>
                            ${consultation.status === 'confirmed' && consultation.meetingLink ? 
                                `<a href="${consultation.meetingLink}" class="btn btn-sm btn-success mt-2" target="_blank">
                                    <i class="fas fa-video me-1"></i>Join Meeting
                                </a>` : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }
}

// Initialize teledentistry marketplace
const teledentistryMarketplace = new TeledentistryMarketplace();

// Show Teledentistry Marketplace
function showTeledentistryMarketplace() {
    if (!document.getElementById('teledentistryModal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="modal fade" id="teledentistryModal" tabindex="-1">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-gradient-primary text-white">
                            <h5 class="modal-title">
                                <i class="fas fa-video me-2"></i>Teledentistry Marketplace
                                <span class="badge bg-warning ms-2">BETA</span>
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <ul class="nav nav-tabs mb-4" id="teledentistryTabs">
                                <li class="nav-item">
                                    <a class="nav-link active" data-bs-toggle="tab" href="#findSpecialists">
                                        <i class="fas fa-search me-2"></i>Find Specialists
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" href="#myConsultations">
                                        <i class="fas fa-history me-2"></i>My Consultations
                                    </a>
                                </li>
                            </ul>
                            
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="findSpecialists">
                                    <div class="search-filters mb-4">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <select class="form-select" id="specialtyFilter">
                                                    <option value="">All Specialties</option>
                                                    <option value="endodontist">Endodontist</option>
                                                    <option value="orthodontist">Orthodontist</option>
                                                    <option value="oral surgeon">Oral Surgeon</option>
                                                    <option value="periodontist">Periodontist</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <select class="form-select" id="ratingFilter">
                                                    <option value="0">Any Rating</option>
                                                    <option value="4.5">4.5+ Stars</option>
                                                    <option value="4.0">4.0+ Stars</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <select class="form-select" id="feeFilter">
                                                    <option value="10000">Any Price</option>
                                                    <option value="2000">Under ₹2000</option>
                                                    <option value="1500">Under ₹1500</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div id="specialistsList" class="row">
                                        <!-- Specialists will be loaded here -->
                                    </div>
                                </div>
                                
                                <div class="tab-pane fade" id="myConsultations">
                                    <div id="consultationHistory">
                                        <!-- Consultation history will be loaded here -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        setupTeledentistryEvents();
    }
    
    loadSpecialists();
    loadConsultationHistory();
    new bootstrap.Modal(document.getElementById('teledentistryModal')).show();
}

function setupTeledentistryEvents() {
    // Filter change events
    ['specialtyFilter', 'ratingFilter', 'feeFilter'].forEach(filterId => {
        document.getElementById(filterId).addEventListener('change', loadSpecialists);
    });
}

function loadSpecialists() {
    const specialty = document.getElementById('specialtyFilter')?.value || '';
    const minRating = parseFloat(document.getElementById('ratingFilter')?.value || '0');
    const maxFee = parseInt(document.getElementById('feeFilter')?.value || '10000');
    
    const specialists = teledentistryMarketplace.searchSpecialists(specialty, minRating, maxFee);
    const container = document.getElementById('specialistsList');
    
    if (container) {
        container.innerHTML = specialists.map(specialist => 
            teledentistryMarketplace.renderSpecialistCard(specialist)
        ).join('');
    }
}

function loadConsultationHistory() {
    const container = document.getElementById('consultationHistory');
    if (container) {
        container.innerHTML = teledentistryMarketplace.renderConsultationHistory();
    }
}

function bookTeledentistryConsultation(specialistId) {
    const specialist = teledentistryMarketplace.specialists.find(s => s.id === specialistId);
    if (!specialist) return;
    
    if (!currentUser) {
        showAlert('Please login to book a consultation.', 'warning');
        showLogin();
        return;
    }
    
    // Show booking form
    if (!document.getElementById('consultationBookingModal')) {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="modal fade" id="consultationBookingModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title">Book Video Consultation</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="specialist-summary mb-3">
                                <div class="d-flex align-items-center">
                                    <div class="specialist-avatar me-3">${specialist.avatar}</div>
                                    <div>
                                        <h6>${specialist.name}</h6>
                                        <p class="mb-0 text-primary">${specialist.specialty}</p>
                                        <small class="text-success">₹${specialist.consultationFee} per consultation</small>
                                    </div>
                                </div>
                            </div>
                            
                            <form id="consultationBookingForm">
                                <div class="mb-3">
                                    <label class="form-label">Consultation Type</label>
                                    <select class="form-select" name="consultationType" required>
                                        <option value="">Select type...</option>
                                        <option value="second-opinion">Second Opinion</option>
                                        <option value="follow-up">Follow-up</option>
                                        <option value="emergency">Emergency Consultation</option>
                                        <option value="general">General Consultation</option>
                                    </select>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Preferred Date</label>
                                        <input type="date" class="form-control" name="preferredDate" required 
                                               min="${new Date().toISOString().split('T')[0]}">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Preferred Time</label>
                                        <select class="form-select" name="preferredTime" required>
                                            <option value="">Select time...</option>
                                            <option value="09:00">9:00 AM</option>
                                            <option value="10:00">10:00 AM</option>
                                            <option value="11:00">11:00 AM</option>
                                            <option value="14:00">2:00 PM</option>
                                            <option value="15:00">3:00 PM</option>
                                            <option value="16:00">4:00 PM</option>
                                            <option value="17:00">5:00 PM</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Describe your symptoms/concerns</label>
                                    <textarea class="form-control" name="symptoms" rows="3" required 
                                              placeholder="Please describe your dental concerns in detail..."></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Upload Files (X-rays, Photos) - Optional</label>
                                    <input type="file" class="form-control" name="files" multiple 
                                           accept="image/*,.pdf" id="consultationFiles">
                                    <small class="text-muted">Max 5MB per file. Supported: JPG, PNG, PDF</small>
                                </div>
                                
                                <div class="consultation-fee-summary p-3 bg-light rounded">
                                    <div class="d-flex justify-content-between">
                                        <span>Consultation Fee:</span>
                                        <strong>₹${specialist.consultationFee}</strong>
                                    </div>
                                    <small class="text-muted">Payment will be processed after confirmation</small>
                                </div>
                                
                                <button type="submit" class="btn btn-primary w-100 mt-3">
                                    <i class="fas fa-calendar-check me-2"></i>Book Consultation
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        document.getElementById('consultationBookingForm').addEventListener('submit', function(e) {
            e.preventDefault();
            handleConsultationBooking(specialistId, e.target);
        });
    }
    
    new bootstrap.Modal(document.getElementById('consultationBookingModal')).show();
}

function handleConsultationBooking(specialistId, form) {
    const formData = new FormData(form);
    const files = Array.from(formData.getAll('files')).filter(file => file.size > 0);
    
    const consultation = teledentistryMarketplace.bookConsultation(
        specialistId,
        formData.get('consultationType'),
        formData.get('preferredDate'),
        formData.get('preferredTime'),
        formData.get('symptoms'),
        files.map(file => ({ name: file.name, size: file.size, type: file.type }))
    );
    
    if (consultation) {
        showAlert('Consultation booked successfully! You will receive confirmation within 24 hours.', 'success');
        
        // Close modals
        const bookingModal = bootstrap.Modal.getInstance(document.getElementById('consultationBookingModal'));
        bookingModal.hide();
        
        // Refresh consultation history
        loadConsultationHistory();
        
        form.reset();
    } else {
        showAlert('Failed to book consultation. Please try again.', 'danger');
    }
}

function viewSpecialistProfile(specialistId) {
    const specialist = teledentistryMarketplace.specialists.find(s => s.id === specialistId);
    if (!specialist) return;
    
    showAlert(`Viewing profile for ${specialist.name} - ${specialist.specialty}`, 'info');
}

// Add to global scope
window.showTeledentistryMarketplace = showTeledentistryMarketplace;