// Gallery functionality
function filterGallery(category) {
    const items = document.querySelectorAll('.gallery-item');
    const buttons = document.querySelectorAll('.btn-group .btn');
    
    // Update active button
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter items
    items.forEach(item => {
        if (category === 'all' || item.dataset.category === category) {
            item.style.display = 'block';
            item.style.animation = 'fadeIn 0.5s ease-in-out';
        } else {
            item.style.display = 'none';
        }
    });
}

function openLightbox(imageId) {
    const modal = new bootstrap.Modal(document.getElementById('lightboxModal'));
    const title = document.getElementById('lightboxTitle');
    const content = document.getElementById('lightboxContent');
    
    const images = {
        'reception': {
            title: 'Modern Reception Area',
            content: '<div class="placeholder-image facility-bg large"><i class="fas fa-clinic-medical"></i><span>Comfortable waiting area with modern amenities</span></div>'
        },
        'treatment': {
            title: 'State-of-the-Art Treatment Room',
            content: '<div class="placeholder-image facility-bg large"><i class="fas fa-procedures"></i><span>Advanced dental equipment for optimal care</span></div>'
        },
        'whitening': {
            title: 'Teeth Whitening Results',
            content: '<div class="before-after-container"><div class="placeholder-image before-after-bg large"><i class="fas fa-magic"></i><span>Amazing whitening transformation</span></div></div>'
        },
        'dr-smith': {
            title: 'Dr. John Smith',
            content: '<div class="placeholder-image team-bg large"><i class="fas fa-user-md"></i><span>Lead General Dentist</span></div>'
        },
        'xray': {
            title: 'Digital X-Ray Room',
            content: '<div class="placeholder-image facility-bg large"><i class="fas fa-x-ray"></i><span>Latest digital imaging technology</span></div>'
        },
        'braces': {
            title: 'Orthodontic Treatment',
            content: '<div class="placeholder-image before-after-bg large"><i class="fas fa-cog"></i><span>Perfect smile alignment results</span></div>'
        }
    };
    
    const imageData = images[imageId];
    title.textContent = imageData.title;
    content.innerHTML = imageData.content;
    
    modal.show();
}